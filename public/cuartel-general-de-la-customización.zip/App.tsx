
import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import HomePage from './components/HomePage';
import LabPage from './components/LabPage';
import GalleryPage from './components/GalleryPage';
import ProfilePage from './components/ProfilePage';
import MissionsPage from './components/MissionsPage';

const App: React.FC = () => {
  return (
    <HashRouter>
      <div className="flex flex-col min-h-screen bg-primary-dark">
        <Header />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/laboratorio" element={<LabPage />} />
            <Route path="/galeria" element={<GalleryPage />} />
            <Route path="/perfil" element={<ProfilePage />} />
            <Route path="/misiones" element={<MissionsPage />} />
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </HashRouter>
  );
};

export default App;
