export interface HeroIdea {
  name: string;
  backstory: string;
  visuals: {
    armorStyle: string;
    primaryColor: string;
    secondaryColor: string;
    accessories: string[];
  };
}

export interface NavItem {
  name: string;
  path: string;
}

export interface GalleryHero {
  id: number;
  name: string;
  creator: string;
  imageUrl: string;
  story: string;
}
