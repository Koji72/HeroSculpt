
import { GoogleGenAI, Type } from "@google/genai";
import { HeroIdea } from '../types';

if (!process.env.API_KEY) {
  // This is a placeholder for environments where the key might not be set.
  // In a real production environment, this check might be handled differently.
  console.warn("API_KEY environment variable not set. Gemini API calls will fail.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || " " });

const heroIdeaSchema = {
  type: Type.OBJECT,
  properties: {
    name: { type: Type.STRING, description: "A cool, catchy superhero name." },
    backstory: { type: Type.STRING, description: "A very short, 1-2 sentence backstory for the hero." },
    visuals: {
      type: Type.OBJECT,
      properties: {
        armorStyle: { type: Type.STRING, description: "e.g., 'Sleek Nanotech', 'Bulky Power Armor', 'Mythical Asgardian Plates'" },
        primaryColor: { type: Type.STRING, description: "The main color of the armor, as a hex code or name. e.g., '#FF0000' or 'Crimson'" },
        secondaryColor: { type: Type.STRING, description: "An accent color. e.g., '#FFFF00' or 'Gold'" },
        accessories: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
          description: "List of 2-3 key accessories. e.g., 'Energy Sword', 'Holographic Cape', 'Shoulder-mounted cannon'"
        },
      },
      required: ["armorStyle", "primaryColor", "secondaryColor", "accessories"],
    },
  },
  required: ["name", "backstory", "visuals"],
};

export const generateHeroIdea = async (): Promise<HeroIdea | null> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: "Generate a unique and compelling superhero concept. It should be inspiring for creating a 3D model. Provide a name, a brief backstory, and key visual elements.",
      config: {
        responseMimeType: "application/json",
        responseSchema: heroIdeaSchema,
        temperature: 1,
      },
    });

    const jsonText = response.text.trim();
    if (!jsonText) {
      throw new Error("API returned an empty response.");
    }
    
    return JSON.parse(jsonText) as HeroIdea;

  } catch (error) {
    console.error("Error generating hero idea with Gemini:", error);
    // In a real app, you'd want more robust error handling, maybe returning a specific error object.
    return null;
  }
};
