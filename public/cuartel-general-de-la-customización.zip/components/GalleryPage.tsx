import React from 'react';
import { GalleryHero } from '../types';
import HeroCard from './HeroCard';

const mockHeroes: GalleryHero[] = [
    { id: 1, name: 'Cyberion', creator: 'User123', imageUrl: 'https://picsum.photos/seed/hero1/500/700', story: 'A knight from a fallen kingdom, resurrected with cybernetics to seek vengeance.' },
    { id: 2, name: 'Novaflare', creator: 'Artisan_AI', imageUrl: 'https://picsum.photos/seed/hero2/500/750', story: 'Born from a dying star, Novaflare wields cosmic fire to protect the innocent.' },
    { id: 3, name: 'Rift-Walker', creator: 'DimensionDrifter', imageUrl: 'https://picsum.photos/seed/hero3/500/650', story: 'An explorer who can step between realities, forever searching for her lost home.' },
    { id: 4, name: 'Giga-Golem', creator: 'BuilderBob', imageUrl: 'https://picsum.photos/seed/hero4/500/800', story: 'An ancient earth elemental bound to a suit of high-tech armor.' },
    { id: 5, name: 'Shadowcat', creator: 'NightProwler', imageUrl: 'https://picsum.photos/seed/hero5/500/720', story: 'A master thief with the ability to become one with the shadows.' },
    { id: 6, name: 'Aegis Prime', creator: 'TheForge', imageUrl: 'https://picsum.photos/seed/hero6/500/780', story: 'The last line of defense, a sentinel created to shield humanity from cosmic threats.' },
    { id: 7, name: 'Mind-Weaver', creator: 'Psyche', imageUrl: 'https://picsum.photos/seed/hero7/500/680', story: 'A powerful telepath who can construct entire worlds within the minds of others.' },
    { id: 8, name: 'Tidal-Lord', creator: 'DeepBlue', imageUrl: 'https://picsum.photos/seed/hero8/500/730', story: 'Ruler of the abyssal plains, commanding the very oceans to his will.' },
];


const GalleryPage: React.FC = () => {
    return (
        <div className="container mx-auto px-6 py-12 animate-fadeIn">
            <div className="text-center mb-12">
                <h1 className="text-5xl font-bold font-display text-neon-cyan mb-2">Galería de Héroes</h1>
                <p className="text-xl text-gray-300">Explora las creaciones de nuestra increíble comunidad.</p>
            </div>

            {/* Filters and Search */}
            <div className="mb-8 flex flex-col md:flex-row gap-4 items-center p-4 bg-light-gray/50 rounded-lg border border-accent-gray">
                <input
                    type="search"
                    placeholder="Buscar por nombre o creador..."
                    className="w-full md:flex-1 bg-primary-dark border-2 border-accent-gray rounded-md px-4 py-2 focus:outline-none focus:border-neon-cyan transition-colors"
                />
                <div className="flex gap-2">
                    <button className="px-4 py-2 bg-accent-gray rounded-md hover:bg-neon-cyan/50 transition-colors">Recientes</button>
                    <button className="px-4 py-2 bg-accent-gray rounded-md hover:bg-neon-cyan/50 transition-colors">Populares</button>
                    <button className="px-4 py-2 bg-neon-cyan text-primary-dark font-bold rounded-md hover:bg-white transition-colors">Filtrar</button>
                </div>
            </div>

            {/* Gallery Grid */}
            <div
              className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6"
              style={{gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))'}}
            >
                {mockHeroes.map((hero, index) => (
                    <HeroCard key={hero.id} hero={hero} />
                ))}
            </div>

            <div className="text-center mt-12">
                <button className="px-8 py-3 border-2 border-neon-purple text-neon-purple font-bold uppercase tracking-widest rounded-md hover:bg-neon-purple hover:text-white hover:shadow-neon-purple transition-all duration-300">
                    Cargar Más
                </button>
            </div>
        </div>
    );
};

export default GalleryPage;
