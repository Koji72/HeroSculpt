import React from 'react';
import { GalleryHero } from '../types';

interface HeroCardProps {
  hero: GalleryHero;
}

const HeroCard: React.FC<HeroCardProps> = ({ hero }) => {
  return (
    <div className="group relative overflow-hidden rounded-lg shadow-lg bg-light-gray border border-accent-gray/50 transform hover:-translate-y-2 transition-transform duration-300 ease-in-out animate-fadeIn">
      <img src={hero.imageUrl} alt={hero.name} className="w-full h-auto object-cover transition-transform duration-500 group-hover:scale-110" />
      
      {/* Static overlay at the bottom */}
      <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent">
        <h3 className="text-2xl font-bold font-display text-white drop-shadow-lg">{hero.name}</h3>
      </div>
      
      {/* Hover overlay for details */}
      <div className="absolute inset-0 bg-black/80 p-6 flex flex-col justify-end opacity-0 group-hover:opacity-100 transition-opacity duration-500">
        <div>
          <h3 className="text-3xl font-bold font-display text-neon-cyan drop-shadow-lg mb-2">{hero.name}</h3>
          <p className="text-sm text-gray-300 mb-1">Creado por: <span className="font-bold text-white">{hero.creator}</span></p>
          <p className="text-gray-200 italic mb-4 text-ellipsis overflow-hidden">"{hero.story}"</p>
          <div className="flex space-x-2">
            <button className="flex-1 py-2 text-sm bg-neon-cyan text-primary-dark font-bold rounded-md hover:bg-white transition-colors">Ver Detalles</button>
            <button className="py-2 px-3 bg-accent-gray rounded-md hover:bg-neon-purple transition-colors" title="Like">
              ❤️
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HeroCard;
