import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { NavItem } from '../types';

const navItems: NavItem[] = [
  { name: 'Laboratorio', path: '/laboratorio' },
  { name: 'Galería', path: '/galeria' },
  { name: 'Misiones', path: '/misiones' },
  { name: 'Perfil', path: '/perfil' },
];

const Header: React.FC = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location]);

  const activeLinkStyle = {
    color: '#00FFFF',
    textShadow: '0 0 5px #00FFFF',
  };

  return (
    <>
      <header className="bg-primary-dark/80 backdrop-blur-sm sticky top-0 z-50 border-b border-light-gray/50">
        <nav className="container mx-auto px-6 py-4 flex justify-between items-center">
          <NavLink to="/" className="text-2xl font-bold font-display text-white hover:text-neon-cyan transition-colors z-50">
            CGC
          </NavLink>
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <NavLink
                key={item.name}
                to={item.path}
                className="font-semibold text-lg text-gray-300 hover:text-neon-cyan transition-colors duration-300"
                style={({ isActive }) => (isActive ? activeLinkStyle : {})}
              >
                {item.name}
              </NavLink>
            ))}
          </div>
          <button
            className="md:hidden text-gray-300 hover:text-neon-cyan z-50"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? (
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            ) : (
               <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" />
              </svg>
            )}
          </button>
        </nav>
      </header>

      {/* Mobile Menu Overlay */}
      <div className={`fixed inset-0 bg-primary-dark/95 z-40 flex flex-col items-center justify-center space-y-8 transition-opacity duration-300 md:hidden ${isMobileMenuOpen ? 'opacity-100 visible' : 'opacity-0 invisible'}`}>
        {navItems.map((item) => (
            <NavLink
              key={item.name}
              to={item.path}
              className="font-semibold text-3xl text-gray-300 hover:text-neon-cyan transition-colors duration-300"
              style={({ isActive }) => (isActive ? activeLinkStyle : {})}
            >
              {item.name}
            </NavLink>
          ))}
      </div>
    </>
  );
};

export default Header;
