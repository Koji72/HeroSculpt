
import React from 'react';
import { Link } from 'react-router-dom';

const HomePage: React.FC = () => {
    return (
        <div className="animate-fadeIn">
            {/* Hero Section */}
            <section className="relative h-[70vh] min-h-[500px] flex items-center justify-center text-center overflow-hidden">
                <div className="absolute inset-0 bg-primary-dark z-0">
                    <img src="https://picsum.photos/seed/scifi/1920/1080" alt="Sci-fi Batcave background" className="w-full h-full object-cover opacity-20" />
                    <div className="absolute inset-0 bg-gradient-to-t from-primary-dark via-primary-dark/50 to-transparent"></div>
                </div>
                <div className="relative z-10 px-4">
                    <h1 className="text-5xl md:text-7xl font-black font-display uppercase tracking-wider text-white">
                        Bienvenido al <span className="text-neon-cyan" style={{textShadow: '0 0 8px #00FFFF'}}>Cuartel General</span>
                    </h1>
                    <p className="mt-4 text-xl md:text-2xl text-gray-300 font-light">
                        Crea. Personaliza. Da vida a tus héroes.
                    </p>
                    <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
                        <Link to="/laboratorio" className="w-full sm:w-auto px-8 py-4 bg-neon-cyan text-primary-dark font-bold uppercase tracking-widest rounded-md hover:bg-white hover:shadow-neon-cyan transition-all duration-300 transform hover:scale-105">
                            Entrar al Laboratorio
                        </Link>
                        <Link to="/galeria" className="w-full sm:w-auto px-8 py-4 border-2 border-neon-purple text-neon-purple font-bold uppercase tracking-widest rounded-md hover:bg-neon-purple hover:text-white hover:shadow-neon-purple transition-all duration-300 transform hover:scale-105">
                            Explorar Galería
                        </Link>
                    </div>
                </div>
            </section>

            {/* How It Works Section */}
            <section className="py-20 bg-black/30">
                <div className="container mx-auto px-6 text-center">
                    <h2 className="text-4xl font-bold font-display text-white mb-12">Tu Aventura Comienza en 3 Pasos</h2>
                    <div className="grid md:grid-cols-3 gap-12">
                        <div className="p-8 border border-accent-gray rounded-lg bg-light-gray/20 hover:border-neon-cyan transition-colors duration-300">
                            <div className="text-5xl text-neon-cyan mb-4">1</div>
                            <h3 className="text-2xl font-bold mb-2">CREA</h3>
                            <p className="text-gray-400">Esculpe tu héroe desde cero en nuestro Laboratorio 3D. Elige arquetipos, partes y accesorios.</p>
                        </div>
                        <div className="p-8 border border-accent-gray rounded-lg bg-light-gray/20 hover:border-neon-cyan transition-colors duration-300">
                             <div className="text-5xl text-neon-cyan mb-4">2</div>
                            <h3 className="text-2xl font-bold mb-2">COMPARTE</h3>
                            <p className="text-gray-400">Exhibe tu creación en la Galería, inspira a otros y recibe feedback de la comunidad.</p>
                        </div>
                        <div className="p-8 border border-accent-gray rounded-lg bg-light-gray/20 hover:border-neon-cyan transition-colors duration-300">
                             <div className="text-5xl text-neon-cyan mb-4">3</div>
                            <h3 className="text-2xl font-bold mb-2">MATERIALIZA</h3>
                            <p className="text-gray-400">Encarga una impresión 3D de alta calidad de tu mini y tráela al mundo real.</p>
                        </div>
                    </div>
                </div>
            </section>

             {/* Testimonials Section */}
            <section className="py-20">
                <div className="container mx-auto px-6">
                    <h2 className="text-4xl font-bold font-display text-center text-white mb-12">Ecos de la Comunidad</h2>
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {[1, 2, 3].map(i => (
                            <div key={i} className="bg-light-gray p-6 rounded-lg border border-accent-gray flex flex-col items-center text-center">
                                <img src={`https://picsum.photos/seed/user${i}/100/100`} alt="User avatar" className="w-24 h-24 rounded-full mb-4 border-2 border-neon-purple" />
                                <p className="text-gray-300 italic mb-4">"¡La herramienta más increíble para dar vida a mis personajes de rol! La calidad es asombrosa."</p>
                                <h4 className="font-bold text-neon-cyan">- HeroMaker_0{i}</h4>
                            </div>
                        ))}
                    </div>
                </div>
            </section>
        </div>
    );
};

export default HomePage;
