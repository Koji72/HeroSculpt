
import React from 'react';

const ProfilePage: React.FC = () => {
    return (
        <div className="container mx-auto px-6 py-12 text-center">
            <h1 className="text-5xl font-bold font-display text-neon-cyan mb-4">Torre de Control</h1>
            <p className="text-xl text-gray-300">Tu perfil personal y colecciones de héroes. ¡Funcionalidad en desarrollo!</p>
        </div>
    );
};

export default ProfilePage;
