import React, { useState, useCallback } from 'react';
import { HeroIdea } from '../types';
import { generateHeroIdea } from '../services/geminiService';

const parts = {
  arquetipos: ['Cyborg Knight', 'Bio-Mage', 'Rogue Scout', 'Cosmic Paladin', 'IA Generated Style'],
  cabeza: ['Helmet A', 'Hood', 'Cyborg Head', 'Crown', 'IA Suggestion'],
  torso: ['Heavy Armor', 'Light Vest', 'Robes', 'Exosuit', 'IA Suggestion'],
  piernas: ['Armored Legs', 'Stealth Pants', 'Robotic Struts', 'IA Suggestion'],
  accesorios: ['Cape', 'Jetpack', 'Shoulder Cannon', 'Energy Shield', 'IA Suggestion'],
};

const colors = ['#FF3B30', '#FF9500', '#FFCC00', '#34C759', '#00C7BE', '#30B0C7', '#32ADE6', '#007AFF', '#5856D6', '#AF52DE', '#FFFFFF', '#8E8E93'];

const LabPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState('arquetipos');
  const [selections, setSelections] = useState<Record<string, string>>({});
  const [primaryColor, setPrimaryColor] = useState('#32ADE6');
  const [secondaryColor, setSecondaryColor] = useState('#FFFFFF');
  
  const [idea, setIdea] = useState<HeroIdea | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleGenerateIdea = useCallback(async () => {
    setIsLoading(true);
    setIdea(null);
    const result = await generateHeroIdea();
    if (result) {
      setIdea(result);
      setPrimaryColor(result.visuals.primaryColor);
      setSecondaryColor(result.visuals.secondaryColor);
      setSelections({
        arquetipos: result.visuals.armorStyle,
        accesorios: result.visuals.accessories.join(', '),
        cabeza: 'IA Suggestion',
        torso: 'IA Suggestion',
        piernas: 'IA Suggestion',
      });
    }
    setIsLoading(false);
  }, []);

  return (
    <div className="min-h-screen flex flex-col lg:flex-row p-4 gap-4 bg-black/20 animate-fadeIn">
      {/* Left Sidebar */}
      <aside className="w-full lg:w-1/4 bg-light-gray/50 rounded-lg p-4 flex flex-col border border-accent-gray">
        <h2 className="text-2xl font-bold font-display text-neon-cyan mb-4">Laboratorio</h2>
        <div className="flex border-b border-accent-gray mb-4 flex-wrap">
          {Object.keys(parts).map((part) => (
            <button
              key={part}
              onClick={() => setActiveTab(part)}
              className={`flex-grow capitalize p-2 text-sm font-bold transition-colors ${activeTab === part ? 'bg-neon-cyan/20 text-neon-cyan' : 'text-gray-300 hover:bg-accent-gray/50'}`}
            >
              {part}
            </button>
          ))}
        </div>
        <div className="overflow-y-auto flex-grow hide-scrollbar">
          <ul className="space-y-2">
            {(parts[activeTab as keyof typeof parts]).map((item) => (
              <li key={item}>
                <button
                  onClick={() => setSelections(prev => ({...prev, [activeTab]: item}))}
                  className={`w-full text-left p-3 rounded-md transition-all duration-200 ${selections[activeTab] === item ? 'bg-neon-cyan text-primary-dark font-bold shadow-neon-cyan' : 'bg-accent-gray hover:bg-neon-cyan/30'}`}
                >
                  {item}
                </button>
              </li>
            ))}
          </ul>
        </div>
      </aside>

      {/* Center 3D Viewer */}
      <main className="flex-1 flex flex-col items-center justify-center bg-light-gray/50 rounded-lg p-4 border border-accent-gray relative">
        <div className="w-full h-full min-h-[400px] bg-primary-dark rounded-md flex items-center justify-center bg-grid-pattern" style={{
            '--grid-color': 'rgba(0, 255, 255, 0.1)',
            '--grid-size': '30px',
            backgroundImage: `linear-gradient(to right, var(--grid-color) 1px, transparent 1px), linear-gradient(to bottom, var(--grid-color) 1px, transparent 1px)`,
            backgroundSize: 'var(--grid-size) var(--grid-size)',
        } as React.CSSProperties}>
          <img src="https://i.imgur.com/KzOGd2e.png" alt="Hero silhouette" className="max-w-full max-h-[80%] object-contain opacity-50" />
           <div className="absolute bottom-4 left-4 bg-primary-dark/80 p-4 rounded-lg text-sm text-gray-300 max-w-xs backdrop-blur-sm border border-accent-gray/50">
            <h3 className="font-bold text-white mb-2 border-b border-accent-gray pb-1">Configuración Actual:</h3>
            <ul className="space-y-1 max-h-24 overflow-y-auto hide-scrollbar">
            {Object.entries(selections).map(([key, value]) => (
                <li key={key}><span className="capitalize font-semibold text-neon-cyan/80">{key}:</span> {value}</li>
            ))}
            </ul>
           </div>
        </div>
         <div className="absolute bottom-4 right-4 flex justify-between items-center">
            <button className="px-6 py-3 bg-neon-cyan text-primary-dark font-bold rounded-md hover:bg-white transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-neon-cyan">Guardar</button>
        </div>
      </main>

      {/* Right Sidebar */}
      <aside className="w-full lg:w-1/4 bg-light-gray/50 rounded-lg p-4 border border-accent-gray flex flex-col">
        <h3 className="text-xl font-bold font-display text-neon-cyan mb-4">Ajustes Finos</h3>
        
        <div className="mb-6 bg-accent-gray/50 p-4 rounded-lg border border-neon-purple/50">
           <h4 className="font-bold text-lg mb-3 text-neon-purple">Inspiración IA</h4>
           <button onClick={handleGenerateIdea} disabled={isLoading} className="w-full px-4 py-2 bg-neon-purple text-white font-bold rounded-md hover:bg-purple-500 transition-colors disabled:bg-gray-600 disabled:cursor-not-allowed flex items-center justify-center">
               {isLoading && <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>}
               {isLoading ? 'Generando...' : 'Generar Idea de Héroe'}
           </button>
           {isLoading && (
             <div className="mt-4 space-y-3 animate-pulse">
                <div className="h-4 bg-gray-600 rounded w-3/4"></div>
                <div className="h-3 bg-gray-600 rounded w-full"></div>
                <div className="h-3 bg-gray-600 rounded w-5/6"></div>
                <div className="h-3 bg-gray-600 rounded w-full"></div>
             </div>
           )}
           {idea && (
             <div className="mt-4 text-sm space-y-2 border-t-2 border-neon-purple/50 pt-3 animate-fadeIn">
                <h5 className="font-bold text-lg text-white">{idea.name}</h5>
                <p className="italic text-gray-300">"{idea.backstory}"</p>
                <p><strong className="text-neon-purple/80">Estilo:</strong> {idea.visuals.armorStyle}</p>
                <p><strong className="text-neon-purple/80">Accesorios:</strong> {idea.visuals.accessories.join(', ')}</p>
             </div>
           )}
        </div>

        <div className="flex-grow">
          <h4 className="font-bold text-lg mb-2">Paleta de Colores</h4>
          <div className="mb-4">
              <label className="block text-sm font-medium text-gray-300 mb-2">Primario: <span className="font-mono p-1 rounded text-xs" style={{backgroundColor: primaryColor, color: '#1A1A1A'}}>{primaryColor}</span></label>
              <div className="flex flex-wrap gap-2">
                  {colors.map(color => <button key={color} onClick={() => setPrimaryColor(color)} className={`w-8 h-8 rounded-full border-2 transition-transform transform hover:scale-110 ${primaryColor === color ? 'border-neon-cyan shadow-neon-cyan' : 'border-transparent'}`} style={{backgroundColor: color}} />)}
              </div>
          </div>
          <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Secundario: <span className="font-mono p-1 rounded text-xs" style={{backgroundColor: secondaryColor, color: '#1A1A1A'}}>{secondaryColor}</span></label>
              <div className="flex flex-wrap gap-2">
                  {colors.map(color => <button key={color} onClick={() => setSecondaryColor(color)} className={`w-8 h-8 rounded-full border-2 transition-transform transform hover:scale-110 ${secondaryColor === color ? 'border-neon-cyan shadow-neon-cyan' : 'border-transparent'}`} style={{backgroundColor: color}} />)}
              </div>
          </div>
        </div>
      </aside>
    </div>
  );
};

export default LabPage;