
import React from 'react';

const SocialIcon: React.FC<{ href: string; children: React.ReactNode }> = ({ href, children }) => (
  <a href={href} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-neon-cyan transition-colors">
    {children}
  </a>
);

const Footer: React.FC = () => {
  return (
    <footer className="bg-black/50 border-t border-light-gray/50 mt-12">
      <div className="container mx-auto px-6 py-8">
        <div className="flex flex-col md:flex-row justify-between items-center text-center md:text-left">
          <div className="mb-4 md:mb-0">
            <h3 className="text-xl font-display font-bold">Cuartel General</h3>
            <p className="text-gray-400">Powered by Mammoth Factory / NemesisForge</p>
          </div>
          <div className="flex space-x-6 mb-4 md:mb-0">
            <a href="#" className="hover:text-neon-cyan">FAQ</a>
            <a href="#" className="hover:text-neon-cyan">Privacy</a>
            <a href="#" className="hover:text-neon-cyan">Contact</a>
            <a href="#" className="hover:text-neon-cyan">Terms</a>
          </div>
          <div className="flex space-x-4">
             <SocialIcon href="#"><svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path fillRule="evenodd" d="M12.315 2c2.43 0 2.784.013 3.808.06 1.064.049 1.791.218 2.427.465a4.902 4.902 0 012.153 1.252A4.902 4.902 0 0122 8.284c.247.636.416 1.363.465 2.427.048 1.024.06 1.378.06 3.808s-.012 2.784-.06 3.808c-.049 1.064-.218 1.791-.465 2.427a4.902 4.902 0 01-1.252 2.153 4.902 4.902 0 01-2.153 1.252c-.636.247-1.363.416-2.427.465-1.024.048-1.378.06-3.808.06s-2.784-.013-3.808-.06c-1.064-.049-1.791-.218-2.427-.465a4.902 4.902 0 01-2.153-1.252A4.902 4.902 0 012 15.716c-.247-.636-.416-1.363-.465-2.427C1.013 12.264 1 11.91 1 9.485s.012-2.784.06-3.808C1.109 4.618 1.278 3.891 1.525 3.255A4.902 4.902 0 013.678 1.102 4.902 4.902 0 015.831.15c.636-.247 1.363-.416 2.427-.465C9.286 2.013 9.64 2 12.315 2zm0 1.62c-2.403 0-2.73.01-3.682.055-.94.043-1.517.2-2.02.385a3.278 3.278 0 00-1.427.826 3.278 3.278 0 00-.826 1.427c-.185.503-.342 1.08-.385 2.02-.045.952-.055 1.279-.055 3.682s.01 2.73.055 3.682c.043.94.2 1.517.385 2.02a3.278 3.278 0 00.826 1.427 3.278 3.278 0 001.427.826c.503.185 1.08.342 2.02.385.952.045 1.279.055 3.682.055s2.73-.01 3.682-.055c.94-.043 1.517-.2 2.02-.385a3.278 3.278 0 001.427-.826 3.278 3.278 0 00.826-1.427c.185-.503.342-1.08.385-2.02.045-.952.055-1.279.055-3.682s-.01-2.73-.055-3.682c-.043-.94-.2-1.517-.385-2.02a3.278 3.278 0 00-.826-1.427 3.278 3.278 0 00-1.427-.826c-.503-.185-1.08-.342-2.02-.385-.952-.045-1.279-.055-3.682-.055zM12 6.865A5.135 5.135 0 1012 17.135 5.135 5.135 0 0012 6.865zm0 8.63A3.495 3.495 0 1112 8.505a3.495 3.495 0 010 6.99zM19.78 4.22a1.2 1.2 0 100 2.4 1.2 1.2 0 000-2.4z" clipRule="evenodd" /></svg></SocialIcon>
             <SocialIcon href="#"><svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path d="M22.46 6c-.77.35-1.6.58-2.46.67.88-.53 1.56-1.37 1.88-2.38-.83.49-1.74.85-2.7 1.03A4.52 4.52 0 0015.65 4a4.49 4.49 0 00-4.49 4.49c0 .34.04.67.11.98-3.73-.19-7.03-1.98-9.24-4.69-.38.65-.6 1.41-.6 2.22 0 1.56.8 2.94 2 3.75-.74-.02-1.43-.23-2.05-.57v.06c0 2.18 1.55 3.99 3.6 4.4-.38.1-.78.15-1.18.15-.29 0-.57-.03-.84-.08.57 1.78 2.24 3.08 4.22 3.12-1.54 1.21-3.48 1.92-5.59 1.92-.36 0-.72-.02-1.07-.06 1.99 1.28 4.36 2.02 6.94 2.02 8.32 0 12.87-6.9 12.87-12.87 0-.2 0-.39-.01-.58A9.17 9.17 0 0024 6.89c-.8.35-1.65.59-2.54.7Z"/></svg></SocialIcon>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
