
import React from 'react';

const MissionsPage: React.FC = () => {
    return (
        <div className="container mx-auto px-6 py-12 text-center">
            <h1 className="text-5xl font-bold font-display text-neon-cyan mb-4">Sala de Misiones</h1>
            <p className="text-xl text-gray-300">Retos, encargos y clasificaciones. ¡Próximamente disponible para todos los héroes!</p>
        </div>
    );
};

export default MissionsPage;
